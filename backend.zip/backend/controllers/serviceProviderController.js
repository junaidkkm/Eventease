import ServiceProvider from '../models/ServiceProvider.js';

// Register service provider
export const registerServiceProvider = async (req, res) => {
  try {
    const { name, email, password, service, contact, location } = req.body;

    const provider = new ServiceProvider({ name, email, password, service, contact, location });
    await provider.save();

    res.status(201).json({ message: 'Service provider registered', provider });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// Login service provider
export const loginServiceProvider = async (req, res) => {
  try {
    const { email, password } = req.body;

    const provider = await ServiceProvider.findOne({ email });
    if (!provider || provider.password !== password) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    res.status(200).json({ message: 'Login successful', provider });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// Get all providers
export const getAllServiceProviders = async (req, res) => {
  try {
    const providers = await ServiceProvider.find();
    if (!providers.length) {
      return res.status(404).json({ message: 'No service providers found' });
    }
    res.json({ providers });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// Get provider by ID
export const getServiceProviderById = async (req, res) => {
  try {
    const provider = await ServiceProvider.findById(req.params.id);
    if (!provider) {
      return res.status(404).json({ message: 'Service provider not found' });
    }
    res.json(provider);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// Update provider
export const updateServiceProvider = async (req, res) => {
  try {
    const updated = await ServiceProvider.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) {
      return res.status(404).json({ message: 'Service provider not found' });
    }
    res.json({ message: 'Updated successfully', provider: updated });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// Delete provider
export const deleteServiceProvider = async (req, res) => {
  try {
    const deleted = await ServiceProvider.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: 'Service provider not found' });
    }
    res.json({ message: 'Deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
