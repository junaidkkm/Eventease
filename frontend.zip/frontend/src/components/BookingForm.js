// src/components/BookingForm.js

import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { createBooking } from '../features/booking/bookingSlice';

const BookingForm = () => {
  const dispatch = useDispatch();
  const [service, setService] = useState('');
  const [date, setDate] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setMessage(''); // Clear any previous message

    dispatch(createBooking({ service, date }))
      .unwrap()
      .then((res) => {
        setMessage(`✅ Booking confirmed for ${res.service} on ${new Date(res.date).toLocaleDateString()}`);
        setService('');
        setDate('');
      })
      .catch((err) => {
        setMessage(`❌ Error: ${err}`);
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Book a Service</h2>
      <input
        type="text"
        placeholder="Service name"
        value={service}
        onChange={(e) => setService(e.target.value)}
        required
      />
      <input
        type="date"
        value={date}
        onChange={(e) => setDate(e.target.value)}
        required
      />
      <button type="submit">Book</button>
      {message && <p>{message}</p>}
    </form>
  );
};

export default BookingForm;
