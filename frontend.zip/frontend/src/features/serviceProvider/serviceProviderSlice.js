import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const API_URL = 'http://localhost:5000/api/providers';

// Get provider profile
export const fetchProviderProfile = createAsyncThunk(
  'provider/fetchProfile',
  async (id, thunkAPI) => {
    try {
      const res = await axios.get(`${API_URL}/${id}`);
      return res.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data.message);
    }
  }
);

// Update provider profile
export const updateProviderProfile = createAsyncThunk(
  'provider/updateProfile',
  async ({ id, data }, thunkAPI) => {
    try {
      const res = await axios.put(`${API_URL}/${id}`, data);
      return res.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data.message);
    }
  }
);

const providerSlice = createSlice({
  name: 'provider',
  initialState: {
    provider: null,
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchProviderProfile.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchProviderProfile.fulfilled, (state, action) => {
        state.loading = false;
        state.provider = action.payload;
      })
      .addCase(updateProviderProfile.fulfilled, (state, action) => {
        state.provider = action.payload;
      })
      .addCase(fetchProviderProfile.rejected, (state, action) => {
        state.error = action.payload;
        state.loading = false;
      })
      .addCase(updateProviderProfile.rejected, (state, action) => {
        state.error = action.payload;
      });
  },
});

export default providerSlice.reducer;
